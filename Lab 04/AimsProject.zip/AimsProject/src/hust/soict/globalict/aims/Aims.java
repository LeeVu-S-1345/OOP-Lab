package hust.soict.globalict.aims;

import java.util.Scanner;

import hust.soict.globalict.aims.cart.Cart;
import hust.soict.globalict.aims.media.CompactDisc;
import hust.soict.globalict.aims.media.DigitalVideoDisc;
import hust.soict.globalict.aims.media.Media;
import hust.soict.globalict.aims.store.Store;

public class Aims {
	
	private Store store = new Store();
	private Cart cart = new Cart();
	
	public static void showMenu() {
		System.out.println("AIMS: "); 
		System.out.println("--------------------------------"); 
		System.out.println("1. View store"); 
		System.out.println("2. Update store"); 
		System.out.println("3. See current cart"); 
		System.out.println("0. Exit"); 
		System.out.println("--------------------------------"); 
		System.out.println("Please choose a number: 0-1-2-3");
	}
	
	public static void storeMenu() {
		System.out.println("Options: ");
		System.out.println("--------------------------------"); 
		System.out.println("1. See a media’s details"); 
		System.out.println("2. Add a media to cart"); 
		System.out.println("3. Play a media"); 
		System.out.println("4. See current cart"); 
		System.out.println("0. Back"); 
		System.out.println("--------------------------------"); 
		System.out.println("Please choose a number: 0-1-2-3-4");
	}
	
	public static void mediaDetailsMenu() { 
		System.out.println("Options: "); 
		System.out.println("--------------------------------"); 
		System.out.println("1. Add to cart"); 
		System.out.println("2. Play"); 
		System.out.println("0. Back"); 
		System.out.println("--------------------------------"); 
		System.out.println("Please choose a number: 0-1-2"); 
	}
	
	public static void cartMenu() { 
		System.out.println("Options: "); 
		System.out.println("--------------------------------"); 
		System.out.println("1. Filter media in cart"); 
		System.out.println("2. Sort media in cart"); 
		System.out.println("3. Remove media from cart"); 
		System.out.println("4. Play a media"); 
		System.out.println("5. Place order"); 
		System.out.println("0. Back"); 
		System.out.println("--------------------------------"); 
		System.out.println("Please choose a number: 0-1-2-3-4-5"); 
	}
	
	public void chooseMainMenu() {
		showMenu();
		Scanner in = new Scanner(System.in);
		int opt = in.nextInt();
		if(opt == 1) {
			viewStore();
		}
		else if(opt == 2) {
			updateStore();
		}
		else if(opt == 3) {
			cart.display();
			cartMenu();
			seeCurrentCart();
		}
		else {
			System.exit(0);
		}
	}

	public void viewStore() {
		store.displayItems();
		storeMenu();
		Scanner in = new Scanner(System.in);
		int opt = in.nextInt();
		if(opt == 1) {
			System.out.print("Enter title of media: ");
			String title = in.nextLine();
			store.seeMediaDetail(title);
			mediaDetailsMenu();
			seeMediaDetails();
		}
		else if(opt == 2) {
			Media media = null;
			cart.addMedia(media);
		}
		else if(opt == 3){
			CompactDisc media = null;
			media.play();
		}
		else if(opt == 4) {
			cart.display();
		}
		else {
			chooseMainMenu();
		}
	}
	
	public void seeMediaDetails() {
		Scanner in = new Scanner(System.in);
		int opt = in.nextInt();
		DigitalVideoDisc media = null;
		if(opt == 1) {
			cart.addMedia(media);
		}
		else if(opt == 2) {
			media.play();
		}
		else {
			viewStore();
		}
	}

	public void updateStore() {
		Scanner in = new Scanner(System.in);
		System.out.println("Add or Remove?");
		String type = in.nextLine();
		if(type.equals("Add")) {
			Media media = null;
			store.addMedia(media);
		}
		else {
			Media media = null;
			store.addMedia(media);
		}
	}
	
	public void seeCurrentCart() {
		Scanner in = new Scanner(System.in);
		int opt = in.nextInt();
		if(opt == 1) {
			System.out.println("filter with id or title:");
			String type = in.nextLine();
			cart.filterCart(type);
		}
		else if(opt == 2) {
			System.out.println("sort by title or cost:");
			String type = in.nextLine();
			cart.sortMedia(type);
		}
		else if(opt == 3) {
			Media media = null;
			cart.removeMedia(media);
		}
		else if(opt == 4) {
			CompactDisc media = null;
			media.play();
		}
		else if(opt == 5) {
			System.out.println("Ordering successfully!");
			cart.clear();
		}
		else {
			chooseMainMenu();
		}
	}
	
	public static void main(String[] args) {
		Aims aims = new Aims();
		aims.chooseMainMenu();
	}
}
