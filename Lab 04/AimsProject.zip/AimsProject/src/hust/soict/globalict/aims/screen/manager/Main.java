package hust.soict.globalict.aims.screen.manager;

import hust.soict.globalict.aims.media.Book;
import hust.soict.globalict.aims.media.CompactDisc;
import hust.soict.globalict.aims.media.DigitalVideoDisc;
import hust.soict.globalict.aims.store.Store;

public class Main {
	
	public static Store store;
	
	public static void main(String[] args) {
		store = new Store();
		store.addMedia(new CompactDisc(0, "Doi muoi", null, "Hoang Dung", null, 200, 27.45f));
		store.addMedia(new Book(1, "Khong gia dinh", null, 30f));
		store.addMedia(new DigitalVideoDisc(1, "The Lion King",
				"Animation", "Roger Allers", 87, 19.95f));
		new StoreManagerScreen(store);
	}

}
