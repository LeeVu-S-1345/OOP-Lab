package hust.soict.globalict.aims.screen.manager;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import hust.soict.globalict.aims.media.DigitalVideoDisc;

public class AddDigitalVideoDiscToStoreScreen extends AddItemToStoreScreen {
	private JLabel lengthLabel, directorLabel;
	private JTextField lengthInput, directorInput;
	private JFrame frame = new JFrame();
	
	public AddDigitalVideoDiscToStoreScreen() {
		super();
		lengthLabel = new JLabel("Length: ");
		lengthInput = new JTextField(10);
		JPanel length = new JPanel(new GridLayout(1, 2, 10, 0));
		length.add(lengthLabel);
		length.add(lengthInput);
		add(length);
		
		directorLabel = new JLabel("Director: ");
		directorInput = new JTextField(20);
		JPanel director = new JPanel(new GridLayout(1, 2, 10, 0));
		director.add(directorLabel);
		director.add(directorInput);
		add(director);
		
		JPanel panel = new JPanel(new BorderLayout());
		
		panel.add(createNorth(), BorderLayout.NORTH);
		getMainPanel().setBorder(new EmptyBorder(10, 250, 250, 250));
		panel.add(getMainPanel(), BorderLayout.CENTER);
		panel.add(createSouth(), BorderLayout.SOUTH);
		
		frame.add(panel);
		frame.setTitle("Adding DVD");
		frame.setSize(800, 600);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
	public JPanel createNorth() {
		JPanel panelNorth = new JPanel(new BorderLayout());
		panelNorth.add(createMenuBar(), BorderLayout.NORTH);
		panelNorth.add(createHeader("Digital Video Disc"), BorderLayout.CENTER);
		return panelNorth;
	}

	@Override
	public JMenuBar createMenuBar() {
		JMenu menu = new JMenu("Options");
		
		JMenuItem viewStore = new JMenuItem("View store");
		viewStore.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new StoreManagerScreen(Main.store);
			}
		});
		menu.add(viewStore);
		
		JMenu smUpdateStore = new JMenu("Update Store");
		JMenuItem addBook = new JMenuItem("Add Book");
		addBook.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new AddBookToStoreScreen();
			}
		});
		smUpdateStore.add(addBook);
		
		JMenuItem addCD = new JMenuItem("Add CD");
		addCD.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new AddCompactDiscToStoreScreen();
			}
		});
		smUpdateStore.add(addCD);
		
		JMenuItem addDVD = new JMenuItem("Add DVD");
		addDVD.setEnabled(false);
		smUpdateStore.add(addDVD);
		menu.add(smUpdateStore);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setLayout(new FlowLayout(FlowLayout.LEFT));
		menuBar.add(menu);
		
		return menuBar;
	}

	@Override
	public JButton createButton() {
		JButton btnFinish = new JButton("Finish");
		btnFinish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String length = lengthInput.getText();
				if(length.equals("")) {
					length = "0";
				}
					Main.store.addMedia(new DigitalVideoDisc(0, getTitle(),
							getCategory(), directorInput.getText(),
							Integer.parseInt(length),
							Float.parseFloat(getCost())));
					btnFinish.setEnabled(false);
					setTitle("");
					setCategory("");
					directorInput.setText("");
					lengthInput.setText("");
					setCost("");
			}
		});
		return btnFinish;
	}
}
