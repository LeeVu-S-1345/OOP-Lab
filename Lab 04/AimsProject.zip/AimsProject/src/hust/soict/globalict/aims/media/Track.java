package hust.soict.globalict.aims.media;

public class Track implements Playable {
	
	private String title;
	private int length;
	
	public Track(String title, int length) {
		this.title = title;
		this.length = length;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) {
			return false;
		}
		Track track = (Track)obj;
		if(track.title == null) {
			return false;
		}
		return this.title.equals(track.title) && this.length == track.length;
	}
	
	public String getTitle() {
		return title;
	}
	public int getLength() {
		return length;
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		if(length <= 0) {
			System.out.println("Cannot play this track!");
		}
		else{
			System.out.println("Playing track: " + title);
			System.out.println("Track length: " + length);
		}
	}
}
