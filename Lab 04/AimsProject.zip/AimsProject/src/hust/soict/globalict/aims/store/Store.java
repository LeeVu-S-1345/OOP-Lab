package hust.soict.globalict.aims.store;

import java.util.ArrayList;
import hust.soict.globalict.aims.media.Media;

public class Store {
	
	private ArrayList<Media> itemsInStore = new ArrayList<Media>();
	
	public void addMedia(Media media) {
		if(itemsInStore.contains(media)) {
			System.out.println("This media is already in the store!");
		}
		else {
			itemsInStore.add(media);
			System.out.println("This media has been added in the store");
		}
	}
	
	public void removeMedia(Media media) {
		if(itemsInStore.contains(media)) {
			itemsInStore.remove(media);
			System.out.println("This media has been removed from the store");
		}
		else {
			System.out.println("This media does not exist in the store");
		}
	}
	
	public void displayItems() {
		if(itemsInStore.size() == 0) {
			System.out.println("There is no item in the store");
			return;
		}
		for(Media m:itemsInStore) {
			System.out.println(m.toString());
		}
	}
	
	public void seeMediaDetail(String title) {
		for(Media m:itemsInStore) {
			if(m.getTitle().equals(title)) {
				System.out.println(m.toString());
				return;
			}
		}
		System.out.println("There is no media matching this title");
	}

	public ArrayList<Media> getItemsInStore() {
		return itemsInStore;
	}
}
