package hust.soict.globalict.aims.cart;

import java.util.ArrayList;
import java.util.Collections;

import hust.soict.globalict.aims.media.Media;

public class Cart {
	
	private ArrayList<Media> itemsOrdered = new ArrayList<Media>();
	
	public void addMedia(Media media) {
		if(itemsOrdered.contains(media)) {
			System.out.println("This media is already in the cart!");
		}
		else {
			itemsOrdered.add(media);
			System.out.println("This media has been added in the cart");
		}
	}
	
	public void removeMedia(Media media) {
		if(itemsOrdered.contains(media)) {
			itemsOrdered.remove(media);
			System.out.println("This media has been removed from the cart");
		}
		else {
			System.out.println("This media does not exist in the cart");
		}
	}
	
	public float totalCost() {
		float sum = 0;
		for(int i = 0; i < itemsOrdered.size(); i++) {
			sum+=itemsOrdered.get(i).getCost();
		}
		return sum;
	}
	
	public void display() {
		for(int i = 0; i < itemsOrdered.size(); i++) {
			System.out.printf("%-5d%-15s%15.2f\n", i+1, 
					itemsOrdered.get(i).getTitle(), itemsOrdered.get(i).getCost());
		}
		System.out.printf("%-5c%-15s%15.2f\n\n", ' ', "Total Cost", totalCost());
	}
	
	public void sortMedia(String option) {
		if(option.equals("title")) {
			Collections.sort(itemsOrdered, Media.COMPARE_BY_TITLE_COST);
		}
		else{
			Collections.sort(itemsOrdered, Media.COMPARE_BY_COST_TITLE);
		}
	}
	
	public void clear() {
		itemsOrdered.clear();
	}
	
	public void filterCart(String option) {
		if(option.equals("id")) {
			int id = 0;
			for(Media m:itemsOrdered) {
				if(m.getId() == id) {
					System.out.println(m.toString());
				}
			}
		}
		else{
			String title = null;
			for(Media m:itemsOrdered) {
				if(m.getTitle().equals(title)) {
					System.out.println(m.toString());
				}
			}
		}	
	}
}
