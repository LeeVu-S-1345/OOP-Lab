package hust.soict.globalict.aims.media;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestPolymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Media> mediae = new ArrayList<Media>();
		//Create a book
		Book book = new Book(4, "Sherlock Holmes", "Investigation", 15f);
		//Create a CD
		CompactDisc cd = new CompactDisc(14, "La lung", "Love", "Vu", "Vu", 180, 20f);
		//Create a DVD
		DigitalVideoDisc dvd = new DigitalVideoDisc(9, "Aladin", "Animation", "George Lucas", 150, 18.99f);
		//Add to mediae
		mediae.add(book);
		mediae.add(cd);
		mediae.add(dvd);
		Book book1 = new Book(7, "Conan", "Investigation", 15f);
		mediae.add(book1);
		CompactDisc cd1 = new CompactDisc(12, "La lung", "Love", "Vu", "Vu", 200, 30f);
		mediae.add(cd1);
		Collections.sort(mediae, Media.COMPARE_BY_COST_TITLE);
		System.out.println("Sort by cost then title:");
		for(Media m:mediae) {
			System.out.println(m.toString());
		}
		Collections.sort(mediae, Media.COMPARE_BY_TITLE_COST);
		System.out.println("\nSort by title then cost:");
		for(Media m:mediae) {
			System.out.println(m.toString());
		}
		System.out.println(cd1.equals("333"));
	}

}
