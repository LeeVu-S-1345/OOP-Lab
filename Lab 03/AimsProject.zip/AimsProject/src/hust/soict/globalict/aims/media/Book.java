package hust.soict.globalict.aims.media;

import java.util.ArrayList;
import java.util.List;

public class Book extends Media{
	
	private List<String> authors = new ArrayList<String>();

	public Book(int id, String title, String category, float cost) {
		super(id, title, category, cost);
	}

	public void addAuthor(String authorName) {
		for(int i = 0; i < authors.size(); i++) {
			if(authors.get(i).equals(authorName)) {
				System.out.printf("This name of author \"%s\" has already added!\n", authorName);
				return;
			}
		}
		authors.add(authorName);
		System.out.printf("This name of author \"%s\" has added successfully!\n", authorName);
	}

	public void removeAuthor(String authorName) {
		if(authors.contains(authorName)) {
			authors.remove(authorName);
			System.out.printf("This name of author \"%s\" has already removed!\n", authorName);
			return;
		}
		System.out.printf("This name of author \"%s\" cannot be removed!\n", authorName);
	}
	
	public String toString() {
		return "Book: (ID " + getId() + ") - " + getTitle() + " - " + getCategory() + " - " + getCost() +"$";
	}
	
}
