package hust.soict.globalict.aims.media;

import java.util.ArrayList;
import java.util.List;

public class CompactDisc extends Disc implements Playable{
	
	private String artist;
	private List<Track> tracks = new ArrayList<Track>();

	public CompactDisc(int id, String title, String category, String artist, float cost) {
		super(id, title, category, cost);
		this.artist = artist;
	}
	
	public CompactDisc(int id, String title, String category, String artist,  String director, float cost) {
		super(id, title, category, director, cost);
		this.artist = artist;
	}
	
	public CompactDisc(int id, String title, String category, String artist, String director, int length, float cost) {
		super(id, title, category, director, length, cost);
		this.artist = artist;
	}
	
	public void addTrack(Track track) {
		for(int i = 0; i < tracks.size(); i++) {
			if(tracks.get(i).equals(track)) {
				System.out.println("This track is already existed in the list!");
				return;
			}
		}
		tracks.add(track);
		System.out.println("This track is already added!");
	}
	
	public void removeTrack(Track track) {
		if(tracks.contains(track)) {
			tracks.remove(track);
			System.out.println("This track is already removed!");
		}
		else {
			System.out.println("This track does not exist in the list!");
		}
	}
	
	public int getLength() {
		int sum = 0;
		for(int i = 0; i < tracks.size(); i++) {
			sum += tracks.get(i).getLength();
		}
		return sum;
	}

	public String getArtist() {
		return artist;
	}
	
	public String toString() {
		return "CompactDisc: (ID " + getId() + ") - " + getTitle() + " - " + getCategory() + artist + " - " +
		getDirector() + " - " + super.getLength() + " - " + getCost() +"$";
	}

	@Override
	public void play() {
		if(super.getLength() <= 0) {
			System.out.println("Cannot play CD");
		}
		else {
			System.out.println(toString());
			for(int i = 0; i < tracks.size(); i++) {
				tracks.get(i).play();
			}
		}
	}

}
