package hust.soict.globalict.test.screen.customer.cart;

import hust.soict.globalict.aims.cart.Cart;
import hust.soict.globalict.aims.media.Book;
import hust.soict.globalict.aims.media.CompactDisc;
import hust.soict.globalict.aims.media.DigitalVideoDisc;
import hust.soict.globalict.aims.screen.customer.controller.CartController;
import hust.soict.globalict.aims.store.Store;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TestViewCartScreen extends Application {
	private static Cart cart;
	private static Store store;

	@Override
	public void start(Stage primaryStage) throws Exception {
		final String CART_FXML_FILE_PATH = "/hust/soict/globalict/aims/screen/customer/view/Cart.fxml";
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(CART_FXML_FILE_PATH));
		CartController cartController = new CartController(store, cart);
		fxmlLoader.setController(cartController);
		Parent root = fxmlLoader.load();
		
		primaryStage.setTitle("Cart");
		primaryStage.setScene(new Scene(root));
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		cart = new Cart();
		cart.addMedia(new CompactDisc(0, "Doi muoi", null, "Hoang Dung", null, 200, 27.45f));
		cart.addMedia(new Book(1, "Khong gia dinh", null, 30f));
		cart.addMedia(new DigitalVideoDisc(2, "The Lion King",
				"Animation", "Roger Allers", 87, 19.95f));
		store = new Store();
		store.addMedia(new CompactDisc(0, "Doi muoi", null, "Hoang Dung", null, 200, 27.45f));
		store.addMedia(new Book(1, "Khong gia dinh", null, 30f));
		store.addMedia(new DigitalVideoDisc(1, "The Lion King",
				"Animation", "Roger Allers", 87, 19.95f));
		launch(args);
	}
}
