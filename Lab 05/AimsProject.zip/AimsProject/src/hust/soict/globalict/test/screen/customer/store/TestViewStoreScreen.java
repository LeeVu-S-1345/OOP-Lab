package hust.soict.globalict.test.screen.customer.store;

import hust.soict.globalict.aims.cart.Cart;
import hust.soict.globalict.aims.media.Book;
import hust.soict.globalict.aims.media.CompactDisc;
import hust.soict.globalict.aims.media.DigitalVideoDisc;
import hust.soict.globalict.aims.screen.customer.controller.ViewStoreController;
import hust.soict.globalict.aims.store.Store;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TestViewStoreScreen extends Application {
	private static Store store;
	private static Cart cart;

	@Override
	public void start(Stage primaryStage) throws Exception {
		final String STORE_FXML_FILE_PATH = "/hust/soict/globalict/aims/screen/customer/view/Store.fxml";
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(STORE_FXML_FILE_PATH));
		ViewStoreController viewStoreController = new ViewStoreController(store, cart);
		fxmlLoader.setController(viewStoreController);
		Parent root = fxmlLoader.load();
		
		primaryStage.setTitle("Store");
		primaryStage.setScene(new Scene(root));
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		store = new Store();
		store.addMedia(new CompactDisc(0, "Doi muoi", null, "Hoang Dung", null, 200, 27.45f));
		store.addMedia(new Book(1, "Khong gia dinh", null, 30f));
		store.addMedia(new DigitalVideoDisc(2, "The Lion King",
				"Animation", "Roger Allers", 87, 19.95f));
		store.addMedia(new DigitalVideoDisc(3, "Star Wars",
				"Science Fiction", "George Lucas", 87, 24.95f));
		store.addMedia(new DigitalVideoDisc(4, "Aladin",
				"Animation", 18.99f));
		store.addMedia(new CompactDisc(14, "Doan ket Moi", null, "Hoang Dung", null, 240, 29.16f));
		store.addMedia(new CompactDisc(26, "La lung", null, "Vu", null, 205, 23.12f));
		store.addMedia(new Book(144, "Sherlock Holmes", "Detective", 32f));
		store.addMedia(new Book(221, "Harry Potter", "Science fiction", 100f));
		store.addMedia( new DigitalVideoDisc(4, "Spider man",
				"Science Fiction", 30.07f));
		
		cart = new Cart();
		launch(args);
	}

}
