package hust.soict.globalict.aims.media;

import hust.soict.globalict.aims.exception.PlayerException;

public class DigitalVideoDisc extends Disc implements Playable{
	
	public DigitalVideoDisc(int id, String title, String category, float cost) {
		super(id, title, category, cost);
	}
	
	public DigitalVideoDisc(int id, String title, String category, String director, float cost) {
		super(id, title, category, director, cost);
	}
	
	public DigitalVideoDisc(int id, String title, String category, String director, int length, float cost) {
		super(id, title, category, director, length, cost);
	}
	
	public String toString() {
		return "DVD: (ID " + getId() + ") - " + getTitle() + " - " + getCategory() + " - " 
				+ getDirector() + " - " + getLength() + ": " + getCost() + "$";
	}
	
	public boolean isMatch(String title) {
		return getTitle().equals(title);
	}

	@Override
	public void play() throws PlayerException {
		// TODO Auto-generated method stub
		if(this.getLength() > 0) {
			System.out.println("Playing DVD: " + this.getTitle()); 
			System.out.println("DVD length: " + this.getLength());
		}
		else {
			throw new PlayerException("ERROR: DVD length is non-positive!");
		}
	}
}
