package hust.soict.globalict.aims.media;

import java.util.ArrayList;
import java.util.List;

public class Book extends Media{
	
	private List<String> authors = new ArrayList<String>();

	public Book(int id, String title, String category, float cost) {
		super(id, title, category, cost);
	}

	public void addAuthor(String authorName) throws AvailableAuthorException {
		if(!authors.contains(authorName)){
			authors.add(authorName);
			System.out.printf("This name of author \"%s\" has added successfully!\n", authorName);
		}
		else {
			throw new AvailableAuthorException("This name of author " + authorName + "has already added!\n");
		}
	}

	public void removeAuthor(String authorName) throws AvailableAuthorException {
		if(authors.contains(authorName)) {
			authors.remove(authorName);
			System.out.printf("This name of author \"%s\" cannot be removed!\n", authorName);
		}
		else{
			throw new AvailableAuthorException("This name of author " + authorName + "has not existed!\n");
		}
	}
	
	public String toString() {
		return "Book: (ID " + getId() + ") - " + getTitle() + " - " + getCategory() + " - " + getCost() +"$";
	}
}

class AvailableAuthorException extends Exception{

	public AvailableAuthorException(String message) {
		super(message);
	}
}

class UnavailableAuthorException extends Exception{

	public UnavailableAuthorException(String message) {
		super(message);
	}
}
