package hust.soict.globalict.aims.exception;

import javax.swing.JOptionPane;

public class PlayerException extends Exception{
	
	public PlayerException(String msg) {
		super(msg);
	}
}
