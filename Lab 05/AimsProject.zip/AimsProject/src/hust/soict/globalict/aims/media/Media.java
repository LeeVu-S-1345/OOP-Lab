package hust.soict.globalict.aims.media;

import java.util.Comparator;

import hust.soict.globalict.aims.exception.PlayerException;

public abstract class Media implements Comparable<Media> {

	public static final Comparator<Media> COMPARE_BY_TITLE_COST = new MediaComparatorByTitleCost();
	public static final Comparator<Media> COMPARE_BY_COST_TITLE = new MediaComparatorByCostTitle();
	private int id;
	private String title;
	private String category;
	private float cost;

	public Media(int id, String title, String category, float cost) {
		this.id = id;
		this.title = title;
		this.category = category;
		if(cost >= 0){
			this.cost = cost;
		}
		else {
			throw new NegativePriceException("ERROR: the cost is negative!");
		}
	}
	
	@Override
	public boolean equals(Object obj) {
		try {
			Media media = (Media)obj;
			if(media.getTitle().equals(title) && media.getCost() == cost) {
				return true;
			}
		} catch(NullPointerException e) {
			e.printStackTrace();
		} catch(ClassCastException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	@Override
	public int compareTo(Media o) {
		try {
			if(title == null || o.getTitle() == null) {
				throw new NullPointerException();
			}
		}catch(NullPointerException e) {
			e.printStackTrace();
		}
		return o.getTitle().compareTo(title);
	}

	public int getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getCategory() {
		return category;
	}

	public float getCost() {
		return cost;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void play() throws PlayerException {
		// TODO Auto-generated method stub
		
	}
}

class NegativePriceException extends RuntimeException{
	
	public NegativePriceException(String msg) {
		super(msg);
	}
}