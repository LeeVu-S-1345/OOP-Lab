package hust.soict.globalict.aims.screen.manager;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import hust.soict.globalict.aims.media.Book;
import hust.soict.globalict.aims.media.DigitalVideoDisc;

public class AddBookToStoreScreen extends AddItemToStoreScreen {
	private JFrame frame = new JFrame();
	
	public AddBookToStoreScreen() {
		super();
		JPanel panel = new JPanel(new BorderLayout());
		
		panel.add(createNorth("Book"), BorderLayout.NORTH);
		getMainPanel().setBorder(new EmptyBorder(10, 200, 200, 200));
		panel.add(getMainPanel(), BorderLayout.CENTER);
		panel.add(createSouth(), BorderLayout.SOUTH);
		
		frame.add(panel);
		frame.setTitle("Adding book");
		frame.setSize(700, 500);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

	@Override
	public JMenuBar createMenuBar() {
		JMenu menu = new JMenu("Options");
		
		JMenuItem viewStore = new JMenuItem("View store");
		viewStore.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new StoreManagerScreen(Main.store);
			}
		});
		menu.add(viewStore);
		
		JMenu smUpdateStore = new JMenu("Update Store");
		JMenuItem addBook = new JMenuItem("Add Book");
		addBook.setEnabled(false);
		smUpdateStore.add(addBook);
		
		JMenuItem addCD = new JMenuItem("Add CD");
		addCD.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new AddCompactDiscToStoreScreen();
			}
		});
		smUpdateStore.add(addCD);
		
		JMenuItem addDVD = new JMenuItem("Add DVD");
		addDVD.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new AddDigitalVideoDiscToStoreScreen();
			}
		});
		smUpdateStore.add(addDVD);
		menu.add(smUpdateStore);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setLayout(new FlowLayout(FlowLayout.LEFT));
		menuBar.add(menu);
		
		return menuBar;
	}

	@Override
	public JButton createButton() {
		JButton btnFinish = new JButton("Finish");
		btnFinish.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Main.store.addMedia(new Book(0, getTitle(),
						getCategory(), Float.parseFloat(getCost())));
				btnFinish.setEnabled(false);
				setTitle("");
				setCategory("");
				setCost("");
			}
		});
		return btnFinish;
	}
}
