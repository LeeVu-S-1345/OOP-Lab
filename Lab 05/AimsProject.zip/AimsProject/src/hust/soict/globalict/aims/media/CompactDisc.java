package hust.soict.globalict.aims.media;

import java.util.ArrayList;
import java.util.List;

import hust.soict.globalict.aims.exception.PlayerException;

public class CompactDisc extends Disc implements Playable{
	
	private String artist;
	private List<Track> tracks = new ArrayList<Track>();

	public CompactDisc(int id, String title, String category, String artist, float cost) {
		super(id, title, category, cost);
		this.artist = artist;
	}
	
	public CompactDisc(int id, String title, String category, String artist,  String director, float cost) {
		super(id, title, category, director, cost);
		this.artist = artist;
	}
	
	public CompactDisc(int id, String title, String category, String artist, String director, int length, float cost) {
		super(id, title, category, director, length, cost);
		this.artist = artist;
	}
	
	public void addTrack(Track track) throws AvailableTrackException {
		if(!tracks.contains(track)) {
			tracks.add(track);
			System.out.println("This track is already added!");
		}
		else {
			throw new AvailableTrackException("This track is already existed in the list!");
		}
	}
	
	public void removeTrack(Track track) throws UnavailableTrackException {
		if(tracks.contains(track)) {
			tracks.remove(track);
			System.out.println("This track is already removed!");
		}
		else {
			throw new UnavailableTrackException("This track did not existed in the list!");
		}
	}
	
	public int getLength() {
		int sum = 0;
		for(int i = 0; i < tracks.size(); i++) {
			sum += tracks.get(i).getLength();
		}
		return sum;
	}

	public String getArtist() {
		return artist;
	}
	
	public String toString() {
		return "CompactDisc: (ID " + getId() + ") - " + getTitle() + " - " + getCategory() + artist + " - " +
		getDirector() + " - " + super.getLength() + " - " + getCost() +"$";
	}

	@Override
	public void play() throws PlayerException {
		if(super.getLength() > 0) {
			java.util.Iterator iter = tracks.iterator();
			Track nextTrack;
			while(iter.hasNext()) {
				nextTrack = (Track) iter.next();
				try {
					nextTrack.play();
				}catch(PlayerException e) {
					throw e;
				}
			}
		}
		else {
			throw new PlayerException("ERROR: CD length is non-positive!");
		}
	}
}

class AvailableTrackException extends RuntimeException{
	public AvailableTrackException(String msg) {
		super(msg);
	}
}

class UnavailableTrackException extends RuntimeException{
	public UnavailableTrackException(String msg) {
		super(msg);
	}
}