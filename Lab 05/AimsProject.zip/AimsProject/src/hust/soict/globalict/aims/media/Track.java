package hust.soict.globalict.aims.media;

import hust.soict.globalict.aims.exception.PlayerException;

public class Track implements Playable {
	
	private String title;
	private int length;
	
	public Track(String title, int length) {
		this.title = title;
		this.length = length;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj == null) {
			return false;
		}
		Track track = (Track)obj;
		if(track.title == null) {
			return false;
		}
		return this.title.equals(track.title) && this.length == track.length;
	}
	
	public String getTitle() {
		return title;
	}
	public int getLength() {
		return length;
	}

	@Override
	public void play() throws PlayerException {
		// TODO Auto-generated method stub
		if(length > 0) {
			System.out.println("Playing track: " + title);
			System.out.println("Track length: " + length);
		}
		else{
			throw new PlayerException("ERROR: Track length is non-positive!");
		}
	}
}
