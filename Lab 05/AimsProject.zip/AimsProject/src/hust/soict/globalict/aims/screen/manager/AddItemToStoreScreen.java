package hust.soict.globalict.aims.screen.manager;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public abstract class AddItemToStoreScreen extends JFrame {
	private JLabel titleLabel, categoryLabel, costLabel;
	private JTextField titleInput, categoryInput, costInput;
	private JPanel main;
	private JButton buttonFinish = new JButton();
	
	public AddItemToStoreScreen() {
		main = new JPanel();
		main.setLayout(new GridLayout(0, 1, 5, 5));
		
		titleLabel = new JLabel("Title*: ");
		titleInput = new JTextField(30);
		titleInput.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(titleInput.getText().equals("") || costInput.getText().equals("")) {
					buttonFinish.setEnabled(false);
				}
				else {
					buttonFinish.setEnabled(true);
				}
			}
		});
		JPanel title = new JPanel(new GridLayout(1, 2, 10, 0));
		title.add(titleLabel);
		title.add(titleInput);
		main.add(title);
		
		categoryLabel = new JLabel("Category: ");
		categoryInput = new JTextField(20);
		JPanel category = new JPanel(new GridLayout(1, 2, 10, 0));
		category.add(categoryLabel);
		category.add(categoryInput);
		main.add(category);
		
		costLabel = new JLabel("Cost*: ");
		costInput = new JTextField(20);
		costInput.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(titleInput.getText().equals("") || costInput.getText().equals("")) {
					buttonFinish.setEnabled(false);
				}
				else {
					buttonFinish.setEnabled(true);
				}
			}
		});
		JPanel cost = new JPanel(new GridLayout(1, 2, 10, 0));
		cost.add(costLabel);
		cost.add(costInput);
		main.add(cost);
	}
	
	public void add(JPanel panel) {
		main.add(panel);
	}
	
	public JPanel getMainPanel() {
		return main;
	}
	
	public JPanel request() {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		
		JLabel rqt = new JLabel("You have to fill all (*) fields");
		rqt.setFont(new Font(rqt.getFont().getName(), Font.PLAIN, 15));
		rqt.setForeground(Color.red);
		
		panel.add(rqt);
		return panel;
	}
	
	public JPanel createNorth(String str) {
		JPanel panelNorth = new JPanel(new BorderLayout());
		panelNorth.add(createMenuBar(), BorderLayout.NORTH);
		panelNorth.add(createHeader(str), BorderLayout.CENTER);
		return panelNorth;
	}
	
	public JPanel createHeader(String str) {
		JPanel header = new JPanel();
		
		JLabel title = new JLabel(str);
		title.setFont(new Font(title.getFont().getName(), Font.PLAIN, 50));
		title.setForeground(Color.CYAN);
		
		header.add(Box.createRigidArea(new Dimension(10, 10)));
		header.add(title, BorderLayout.CENTER);
		header.add(Box.createHorizontalGlue());
		header.add(Box.createRigidArea(new Dimension(10, 10)));
		
		return header;
	}
	
	public JPanel createSouth() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(request(), BorderLayout.WEST);
		buttonFinish = createButton();
		buttonFinish.setEnabled(false);
		panel.add(buttonFinish, BorderLayout.EAST);
		panel.setBorder(new EmptyBorder(0, 5, 5, 5));
		return panel;
	}
	
	public String getTitle() {
		return titleInput.getText();
	}
	
	public String getCategory() {
		return categoryInput.getText();
	}
	
	public String getCost() {
		return costInput.getText();
	}
	
	public void setTitle(String str) {
		titleInput.setText(str);
	}
	
	public void setCategory(String str) {
		categoryInput.setText(str);
	}
	
	public void setCost(String str) {
		costInput.setText(str);
	}
	
	public abstract JButton createButton();

	public abstract JMenuBar createMenuBar();
}
